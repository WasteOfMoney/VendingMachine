package tests

import VendingMachine.Machine

object NoItem {
  val vending: Machine = new Machine

  def main(args: Array[String]): Unit = {

    vending.insertMoney(25)
    println(vending.totalMoney)
    println(vending.changeMoney)
  }
  //Snack costs 20, returns 5 in change
}
